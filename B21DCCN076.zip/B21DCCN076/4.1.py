import re, collections, math, fractions, itertools

paper = None
print("Is paper == None? I predict True.")
print(paper == None)
print("Is paper == True? I predict False.")
print(paper == True)

cat = "Pretty Kitty"
print("Is cat == 'Pretty Kitty'? I predict True.")
print(cat == "Pretty Kitty")
print("Is cat == 'pretty kitty'? I predict False.")
print(cat == "pretty kitty")

pi = math.pi
print("Is pi == math.pi? I predict True.")
print(pi == math.pi)
print("Is pi == 3.141592653589793? I predict True.")
print(pi == 3.141592653589793)
print("Is pi == 3.141592653589793238462643383279502884197169399375105820974944592307816406286? I predict True.")
print(pi == 3.141592653589793238462643383279502884197169399375105820974944592307816406286)
print("Is pi == 3.14? I predict False.")
print(pi == 3.14)

name = "Bryan"
print("Is name == 'bryan'? I predict False.")
print(name == "bryan")
print("Is 1+1 == '2'? I predict False.")
print(1+1 == "2")



