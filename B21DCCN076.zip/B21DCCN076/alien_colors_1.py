import re, collections, math, fractions, itertools

alien_color = 'green'
if alien_color == 'green':
    print("You just earned 5 points!")

alien_color = 'red'
if alien_color == 'green':
    print("You just earned 5 points!")