import re, collections, math, fractions, itertools

favorite_fruits = ['apple', 'banana', 'orange']

if 'apple' in favorite_fruits:
    print("You really like apples!")
if 'banana' in favorite_fruits:
    print("You really like bananas!")
if 'orange' in favorite_fruits:
    print("You really like oranges!")
if 'grape' in favorite_fruits:
    print("You really like grapes!")
if 'watermelon' in favorite_fruits:
    print("You really like watermelons!")